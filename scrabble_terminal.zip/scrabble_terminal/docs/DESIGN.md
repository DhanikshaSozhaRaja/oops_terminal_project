# Design notes

## Core/UI boundary
`Game` owns the board, players, tile bag, dictionary and rules. It does not read terminal input or draw graphics. `main.cpp` is only a terminal adapter. A future SFML UI should call `Game::play`, `Game::pass`, and `Game::exchange` rather than reimplementing rules.

## Move transaction
A play validates coordinates, alignment, overlaps, rack letters, first-move/connectivity rules, dictionary words and score before committing any tile. Failed moves leave the board and score unchanged.

## Current limitations
The first version uses a word-placement command instead of individual tile dragging. It has no blank tiles, challenge mechanism, saved game state, or official tournament dictionary guarantee. Further tests should cover every premium square, cross-word scoring, tile exchanges, and game-over scoring.
