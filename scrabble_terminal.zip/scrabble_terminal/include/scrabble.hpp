#pragma once
#include <array>
#include <cstdint>
#include <random>
#include <string>
#include <unordered_set>
#include <vector>

namespace scrabble {
constexpr int BOARD_SIZE = 15;
constexpr int RACK_SIZE = 7;

struct Position { int row{}; int col{}; };
struct Cell { char letter = ' '; bool occupied = false; };
struct Player { std::string name; int score = 0; std::vector<char> rack; };
struct MoveResult { bool ok = false; std::string message; int points = 0; std::vector<std::string> words; };

class Game {
public:
    explicit Game(std::vector<std::string> names, const std::string& dictionaryPath, unsigned seed = std::random_device{}());
    bool dictionaryLoaded() const { return dictionaryLoaded_; }
    const std::string& dictionaryError() const { return dictionaryError_; }
    const std::array<Cell, BOARD_SIZE * BOARD_SIZE>& board() const { return board_; }
    const std::vector<Player>& players() const { return players_; }
    int currentPlayerIndex() const { return currentPlayer_; }
    Player& currentPlayer() { return players_.at(currentPlayer_); }
    const Player& currentPlayer() const { return players_.at(currentPlayer_); }
    std::size_t tilesRemaining() const { return bag_.size(); }
    bool isGameOver() const { return gameOver_; }
    const std::string& endMessage() const { return endMessage_; }
    MoveResult play(int row, int col, char direction, const std::string& word);
    std::string pass();
    std::string exchange(const std::string& letters);
    char at(int row, int col) const;
    static int letterPoints(char c);
    static char premiumAt(int row, int col);
private:
    std::array<Cell, BOARD_SIZE * BOARD_SIZE> board_{};
    std::vector<Player> players_;
    std::vector<char> bag_;
    std::unordered_set<std::string> dictionary_;
    std::mt19937 rng_;
    int currentPlayer_ = 0;
    int consecutiveScorelessTurns_ = 0;
    bool gameOver_ = false;
    bool dictionaryLoaded_ = false;
    std::string dictionaryError_;
    std::string endMessage_;
    static int index(int row, int col) { return row * BOARD_SIZE + col; }
    static std::string upper(std::string s);
    void fillBag();
    void shuffleBag();
    void drawTiles(Player& p);
    bool hasWord(const std::string& word) const;
    void nextTurn();
    void finishGame(bool rackOut);
    bool rackCanMake(const Player& p, const std::vector<char>& letters, std::vector<char>& remaining) const;
};

void saveHighScore(const Player& p, const std::string& path = "data/highscores.txt");
}
