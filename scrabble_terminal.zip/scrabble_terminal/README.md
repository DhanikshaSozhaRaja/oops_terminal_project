# Scrabble C++ — Terminal Edition

A C++17, terminal-based Scrabble project designed so the game engine can later be reused by an SFML graphical interface.

## Features
- 2–4 local players
- 15×15 board with premium squares
- Standard 98-tile distribution (no blank tiles)
- Dictionary validation for main words and cross-words
- Horizontal and vertical word placement
- Rack validation, scoring multipliers, bingo bonus
- Pass and exchange commands
- Game-over handling and high-score append file
- CMake build and a basic smoke test

## Requirements
- CMake 3.16+
- A C++17 compiler (Visual Studio 2022/MSVC, GCC, or Clang)
- Included `data/dictionary.txt`

No third-party libraries are required for the terminal phase.

## Build on Windows (PowerShell)
Open a terminal in this folder:

```powershell
cmake -S . -B build
cmake --build build --config Debug
ctest --test-dir build -C Debug --output-on-failure
```

Run with the working directory set to the project root:

```powershell
./build/Debug/scrabble.exe
```

For a single-configuration generator such as MinGW Makefiles, the executable may be `build/scrabble.exe` instead.

## Build on Linux/macOS

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
./build/scrabble
```

## Commands
- `PLAY <row> <column-letter> <H|V> <word>` — place a complete word. Example: `PLAY 8 H H CAT`.
- `PASS` — pass your turn.
- `EXCHANGE <letters>` — exchange the specified letters, if enough tiles remain in the bag.
- `BOARD` — redraw the board.
- `HELP` — show help.
- `QUIT` — exit without finalizing the match.

Rows are 1–15 and columns are A–O. `H` means horizontal and `V` means vertical. The word entered must include any existing letters that form part of it. Invalid moves do not modify the board or score.

## Data files
- `data/dictionary.txt` — word list
- `data/highscores.txt` — created/appended after a game ends

Run from the project root so the relative data paths resolve correctly.

## Architecture
- `scrabble_core` (`include/scrabble.hpp`, `src/scrabble.cpp`) contains the model and rules, with no terminal or GUI dependencies.
- `src/main.cpp` is the terminal front end.

For the GUI phase, add an SFML front end that calls the same `Game` API; do not duplicate the game rules in the GUI.

## Known simplifications
This is a basic playable phase, not a tournament-certified Scrabble implementation. It does not include blank tiles, challenge rules, or the official endgame rules for every edge case. The included dictionary is a general English word list and may contain words not accepted by a particular Scrabble authority. The smoke test checks basic initialization and validation paths; it is not a comprehensive rules test suite.
