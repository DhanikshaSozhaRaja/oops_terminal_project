#include "scrabble.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

void printBoard(const scrabble::Game& game) {
    std::cout << "\n    ";
    for (int col = 0; col < scrabble::Game::BOARD_SIZE; ++col) {
        std::cout << (col + 1 < 10 ? " " : "") << (col + 1) << " ";
    }
    std::cout << "\n   +" << std::string(scrabble::Game::BOARD_SIZE * 3, '-') << "+\n";

    for (int row = 0; row < scrabble::Game::BOARD_SIZE; ++row) {
        int rowNumber = row + 1;
        std::cout << (rowNumber < 10 ? " " : "") << rowNumber << " |";
        for (int col = 0; col < scrabble::Game::BOARD_SIZE; ++col) {
            char tile = game.at(row, col);
            std::cout << " " << tile << " ";
        }
        std::cout << "|\n";
    }
    std::cout << "   +" << std::string(scrabble::Game::BOARD_SIZE * 3, '-') << "+\n\n";
}

int main() {
    std::string dictionaryPath = "data/dictionary.txt";
    std::string localPath = "dictionary.txt";

    std::ifstream checkFile(dictionaryPath);
    if (!checkFile.good()) {
        std::ifstream checkLocal(localPath);
        if (checkLocal.good()) {
            dictionaryPath = localPath;
        }
    }

    std::cout << "=================================\n";
    std::cout << "      SCRABBLE TERMINAL GAME     \n";
    std::cout << "=================================\n\n";

    std::vector<std::string> players = {"Player 1", "Player 2"};
    scrabble::Game game(players, dictionaryPath);

    while (true) {
        printBoard(game);

        auto& current = game.currentPlayer();
        std::cout << "Turn: " << current.name << " | Score: " << current.score << "\n";
        std::cout << "Your Rack: [ ";
        for (char tile : current.rack) {
            std::cout << tile << " ";
        }
        std::cout << "]\n\n";

        std::cout << "Enter move (e.g., '8 8 H HELLO') or 'quit' to exit: ";
        std::string input;
        if (!(std::cin >> input) || input == "quit" || input == "QUIT") {
            std::cout << "Thanks for playing!\n";
            break;
        }

        int row = std::stoi(input) - 1;
        int col;
        char dir;
        std::string word;
        std::cin >> col >> dir >> word;
        col -= 1;

        scrabble::MoveResult res = game.play(row, col, dir, word);
        std::cout << "\n> " << res.message << "\n";
    }

    return 0;
}