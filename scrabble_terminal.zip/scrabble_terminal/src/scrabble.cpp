#include "scrabble.h"
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <map>

namespace scrabble {

const std::map<char, std::vector<Position>> Game::PREMIUMS = {
    {'T', {Position(0, 0), Position(0, 7), Position(0, 14), Position(7, 0), Position(7, 14), Position(14, 0), Position(14, 7), Position(14, 14)}},
    {'D', {Position(1, 1), Position(2, 2), Position(3, 3), Position(4, 4), Position(10, 10), Position(11, 11), Position(12, 12), Position(13, 13), Position(1, 13), Position(2, 12), Position(3, 11), Position(4, 10), Position(10, 4), Position(11, 3), Position(12, 2), Position(13, 1), Position(7, 7)}},
    {'t', {Position(1, 5), Position(1, 9), Position(5, 1), Position(5, 5), Position(5, 9), Position(5, 13), Position(9, 1), Position(9, 5), Position(9, 9), Position(9, 13), Position(13, 5), Position(13, 9)}},
    {'d', {Position(0, 3), Position(0, 11), Position(2, 6), Position(2, 8), Position(3, 0), Position(3, 7), Position(3, 14), Position(6, 2), Position(6, 6), Position(6, 8), Position(6, 12), Position(7, 3), Position(7, 11), Position(8, 2), Position(8, 6), Position(8, 8), Position(8, 12), Position(11, 0), Position(11, 7), Position(11, 14), Position(12, 6), Position(12, 8), Position(14, 3), Position(14, 11)}}
};

char Game::premiumAt(int row, int col) {
    for (const auto& pair : PREMIUMS) {
        char kind = pair.first;
        const auto& cells = pair.second;
        for (const auto& p : cells) {
            if (p.row == row && p.col == col) return kind;
        }
    }
    return '.';
}

char Game::at(int row, int col) const {
    if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) return ' ';
    const auto& c = board_[index(row, col)];
    return c.occupied ? c.letter : premiumAt(row, col);
}

Game::Game(std::vector<std::string> names, const std::string& dictionaryPath, unsigned seed)
    : board_(BOARD_SIZE * BOARD_SIZE), rng_(seed), currentPlayerIndex_(0), gameOver_(false) {
    
    fillBag();
    loadDictionary(dictionaryPath);

    for (const auto& name : names) {
        Player p;
        p.name = name;
        p.score = 0;
        players_.push_back(p);
    }

    for (auto& player : players_) {
        refillRack(player);
    }
}

void Game::fillBag() {
    bag_ = {
        'A','A','A','A','A','A','A','A','A', 'B','B', 'C','C', 'D','D','D','D',
        'E','E','E','E','E','E','E','E','E','E','E','E', 'F','F', 'G','G','G',
        'H','H', 'I','I','I','I','I','I','I','I','I', 'J', 'K', 'L','L','L','L',
        'M','M', 'N','N','N','N','N','N', 'O','O','O','O','O','O','O','O',
        'P','P', 'Q', 'R','R','R','R','R','R', 'S','S','S','S', 'T','T','T','T','T','T',
        'U','U','U','U', 'V','V', 'W','W', 'X', 'Y','Y', 'Z'
    };
    std::shuffle(bag_.begin(), bag_.end(), rng_);
}

void Game::loadDictionary(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return;
    std::string word;
    while (file >> word) {
        for (auto& c : word) c = std::toupper(c);
        dictionary_.insert(word);
    }
}

void Game::refillRack(Player& p) {
    while (p.rack.size() < RACK_SIZE && !bag_.empty()) {
        p.rack.push_back(bag_.back());
        bag_.pop_back();
    }
}

Player& Game::currentPlayer() {
    return players_[currentPlayerIndex_];
}

int Game::index(int r, int c) const {
    return r * BOARD_SIZE + c;
}

std::string Game::upper(std::string s) const {
    for (auto& c : s) c = std::toupper(c);
    return s;
}

bool Game::rackCanMake(const Player& p, const std::vector<char>& needed, std::vector<char>& remaining) const {
    remaining = p.rack;
    for (char c : needed) {
        auto it = std::find(remaining.begin(), remaining.end(), c);
        if (it == remaining.end()) return false;
        remaining.erase(it);
    }
    return true;
}

MoveResult Game::play(int row, int col, char direction, const std::string& rawWord) {
    MoveResult result;
    if (gameOver_) { result.message = "The game has ended."; return result; }
    if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) {
        result.message = "Row and column must be between 1 and 15."; return result;
    }
    direction = static_cast<char>(std::toupper(static_cast<unsigned char>(direction)));
    if (direction != 'H' && direction != 'V') {
        result.message = "Direction must be H (horizontal) or V (vertical)."; return result;
    }
    const std::string word = upper(rawWord);
    if (word.empty() || !std::all_of(word.begin(), word.end(), [](char c){ return c >= 'A' && c <= 'Z'; })) {
        result.message = "Enter a valid word containing letters only."; return result;
    }

    const int dr = direction == 'V' ? 1 : 0;
    const int dc = direction == 'H' ? 1 : 0;

    if (row + dr * (static_cast<int>(word.size()) - 1) >= BOARD_SIZE ||
        col + dc * (static_cast<int>(word.size()) - 1) >= BOARD_SIZE) {
        result.message = "Word exceeds board boundary."; return result;
    }

    std::vector<char> needed;
    std::vector<Position> newPositions;
    bool overlaps = false;

    for (std::size_t i = 0; i < word.size(); ++i) {
        int r = row + dr * static_cast<int>(i);
        int c = col + dc * static_cast<int>(i);
        const auto& cell = board_[index(r, c)];
        if (cell.occupied) {
            if (cell.letter != word[i]) {
                result.message = "Conflict with existing tile on board."; return result;
            }
            overlaps = true;
        } else {
            needed.push_back(word[i]);
            newPositions.push_back(Position(r, c));
        }
    }

    if (needed.empty()) {
        result.message = "The move must place at least one new tile."; return result;
    }

    std::vector<char> remaining;
    if (!rackCanMake(currentPlayer(), needed, remaining)) {
        result.message = "Your rack does not contain the required letters."; return result;
    }

    bool touches = false;
    for (auto p : newPositions) {
        Position adj[4] = {
            Position(p.row - 1, p.col),
            Position(p.row + 1, p.col),
            Position(p.row, p.col - 1),
            Position(p.row, p.col + 1)
        };
        for (int k = 0; k < 4; ++k) {
            int ar = adj[k].row;
            int ac = adj[k].col;
            if (ar >= 0 && ar < BOARD_SIZE && ac >= 0 && ac < BOARD_SIZE) {
                if (board_[index(ar, ac)].occupied) touches = true;
            }
        }
    }

    bool boardIsEmpty = std::none_of(board_.begin(), board_.end(), [](const Cell& c){ return c.occupied; });
    
    if (boardIsEmpty) {
        bool coversCenter = false;
        for (auto p : newPositions) {
            if (p.row == 7 && p.col == 7) coversCenter = true;
        }
        if (!coversCenter) {
            result.message = "First move must cover the center cell (8, H / Row 8 Col 8)."; return result;
        }
    } else if (!touches && !overlaps) {
        result.message = "Your move must connect to a tile already on the board."; return result;
    }

    for (std::size_t i = 0; i < word.size(); ++i) {
        int r = row + dr * static_cast<int>(i);
        int c = col + dc * static_cast<int>(i);
        auto& cell = board_[index(r, c)];
        cell.letter = word[i];
        cell.occupied = true;
    }

    currentPlayer().rack = remaining;
    refillRack(currentPlayer());
    currentPlayer().score += static_cast<int>(word.size());

    result.success = true;
    result.message = "Word placed successfully!";
    currentPlayerIndex_ = (currentPlayerIndex_ + 1) % players_.size();
    return result;
}

} 
