@echo off
cd /d "%~dp0"
if not exist build mkdir build
cmake -S . -B build
if errorlevel 1 pause & exit /b 1
cmake --build build --config Debug
if errorlevel 1 pause & exit /b 1
if exist build\Debug\scrabble.exe (
  build\Debug\scrabble.exe
) else if exist build\scrabble.exe (
  build\scrabble.exe
) else (
  echo Could not find scrabble.exe after build.
  pause
  exit /b 1
)
pause
