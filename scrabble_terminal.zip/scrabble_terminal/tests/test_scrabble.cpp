#include "scrabble.hpp"
#include <cassert>
#include <iostream>
int main() {
    using namespace scrabble;
    Game g({"Alice","Bob"}, "data/dictionary.txt", 12345);
    assert(g.dictionaryLoaded());
    assert(g.players().size()==2);
    assert(g.players()[0].rack.size()==7 && g.players()[1].rack.size()==7);
    assert(g.tilesRemaining()==84);
    assert(Game::letterPoints('A')==1 && Game::letterPoints('Z')==10);
    assert(Game::premiumAt(7,7)=='D');
    assert(g.at(7,7)=='D');
    auto bad=g.play(0,0,'H',"CAT");
    assert(!bad.ok);
    auto badDirection=g.play(7,7,'X',"CAT");
    assert(!badDirection.ok);
    std::cout<<"Smoke tests passed.\n";
}
