#include "scrabble.hpp"
#include <algorithm>
#include <cctype>
#include <filesystem>
#include <iostream>
#include <sstream>

using namespace scrabble;
namespace {
void printBoard(const Game& game) {
    std::cout << "\n      A B C D E F G H I J K L M N O\n";
    for(int r=0;r<BOARD_SIZE;++r) { std::cout.width(3); std::cout<<r+1<<"   "; for(int c=0;c<BOARD_SIZE;++c) { char ch=game.at(r,c); if(ch=='.'||ch=='d'||ch=='t'||ch=='D'||ch=='T') std::cout<<ch; else std::cout<<ch; if(c<BOARD_SIZE-1) std::cout<<' '; } std::cout<<'\n'; }
    std::cout<<"Legend: . normal, d double-letter, t triple-letter, D double-word, T triple-word; * centre is double-word\n";
}
void printStatus(const Game& game) {
    std::cout<<"\nTiles in bag: "<<game.tilesRemaining()<<"\nScores: ";
    for(std::size_t i=0;i<game.players().size();++i) { if(i) std::cout<<" | "; std::cout<<game.players()[i].name<<": "<<game.players()[i].score; }
    const auto& p=game.currentPlayer(); std::cout<<"\nCurrent player: "<<p.name<<"\nRack: "; for(char c:p.rack) std::cout<<c<<' '; std::cout<<"\n";
}
void help() {
    std::cout<<"\nCommands:\n"
      <<"  PLAY <row> <column-letter> <H|V> <word>   Example: PLAY 8 H H CAT\n"
      <<"  PASS                                      End your turn without scoring\n"
      <<"  EXCHANGE <letters>                        Example: EXCHANGE AE\n"
      <<"  BOARD                                     Show the board\n"
      <<"  HELP                                      Show commands\n"
      <<"  QUIT                                      Quit without completing the match\n\n"
      <<"PLAY uses the full word including any existing letters. Row is 1-15; column is A-O.\n";
}
}
int main(int argc,char** argv) {
    std::string dictionaryPath="data/dictionary.txt";
    if(argc>1) dictionaryPath=argv[1];
    if(!std::filesystem::exists(dictionaryPath)) {
        const std::string local="../data/dictionary.txt";
        if(std::filesystem::exists(local)) dictionaryPath=local;
    }
    std::cout<<"=================================\n           SCRABBLE C++           \n        Terminal Edition          \n=================================\n";
    int count=0;
    while(count<2||count>4) { std::cout<<"Number of players (2-4): "; std::string line; if(!std::getline(std::cin,line)) return 0; try { count=std::stoi(line); } catch(...) { count=0; } if(count<2||count>4) std::cout<<"Please enter 2, 3, or 4.\n"; }
    std::vector<std::string> names;
    for(int i=0;i<count;++i) { std::cout<<"Name for player "<<i+1<<": "; std::string name; std::getline(std::cin,name); if(name.empty()) name="Player"+std::to_string(i+1); names.push_back(name); }
    Game game(names,dictionaryPath);
    if(!game.dictionaryLoaded()) { std::cerr<<"Error: "<<game.dictionaryError()<<"\nCheck that data/dictionary.txt exists.\n"; return 1; }
    help();
    while(!game.isGameOver()) {
        printBoard(game); printStatus(game); std::cout<<"> ";
        std::string line; if(!std::getline(std::cin,line)) break;
        std::istringstream in(line); std::string cmd; in>>cmd; for(char& c:cmd)c=static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
        if(cmd.empty()) continue;
        if(cmd=="HELP") { help(); continue; }
        if(cmd=="BOARD") continue;
        if(cmd=="QUIT") { std::cout<<"Game stopped. Scores are not finalized.\n"; return 0; }
        if(cmd=="PASS") { std::cout<<game.pass()<<'\n'; continue; }
        if(cmd=="EXCHANGE") { std::string letters; in>>letters; std::cout<<game.exchange(letters)<<'\n'; continue; }
        if(cmd=="PLAY") {
            int row; char col,dir; std::string word;
            if(!(in>>row>>col>>dir>>word)) { std::cout<<"Usage: PLAY <row> <column-letter> <H|V> <word>\n"; continue; }
            col=static_cast<char>(std::toupper(static_cast<unsigned char>(col)));
            if(col<'A'||col>'O') { std::cout<<"Column must be A-O.\n"; continue; }
            MoveResult res=game.play(row-1,col-'A',dir,word);
            std::cout<<res.message<<'\n'; if(res.ok&&!res.words.empty()) { std::cout<<"Words formed: "; for(std::size_t i=0;i<res.words.size();++i) {if(i)std::cout<<", ";std::cout<<res.words[i];} std::cout<<"\n"; }
            continue;
        }
        std::cout<<"Unknown command. Type HELP.\n";
    }
    if(game.isGameOver()) { std::cout<<"\n"<<game.endMessage()<<"\nFinal scores:\n"; for(const auto& p:game.players()) std::cout<<"  "<<p.name<<": "<<p.score<<"\n"; std::cout<<"Scores appended to data/highscores.txt when writable.\n"; }
    return 0;
}
