#include "scrabble.hpp"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <map>
#include <sstream>

namespace scrabble {
namespace {
const std::array<int, 26> POINTS = {1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};
const std::map<char, std::vector<Position>> PREMIUMS = {
 {'T', {{0,0},{0,7},{0,14},{7,0},{7,14},{14,0},{14,7},{14,14}}},
 {'D', {{1,1},{2,2},{3,3},{4,4},{10,10},{11,11},{12,12},{13,13},{1,13},{2,12},{3,11},{4,10},{10,4},{11,3},{12,2},{13,1},{7,7}}},
 {'t', {{1,5},{1,9},{5,1},{5,5},{5,9},{5,13},{9,1},{9,5},{9,9},{9,13},{13,5},{13,9}}},
 {'d', {{0,3},{0,11},{2,6},{2,8},{3,0},{3,7},{3,14},{6,2},{6,6},{6,8},{6,12},{7,3},{7,11},{8,2},{8,6},{8,8},{8,12},{11,0},{11,7},{11,14},{12,6},{12,8},{14,3},{14,11}}}
};
}
std::string Game::upper(std::string s) { for (char& c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c))); return s; }
int Game::letterPoints(char c) { c = static_cast<char>(std::toupper(static_cast<unsigned char>(c))); return c >= 'A' && c <= 'Z' ? POINTS[c-'A'] : 0; }
char Game::premiumAt(int row, int col) { for (const auto& [kind, cells] : PREMIUMS) for (auto p : cells) if (p.row == row && p.col == col) return kind; return '.'; }
char Game::at(int row, int col) const { if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) return ' '; const auto& c = board_[index(row,col)]; return c.occupied ? c.letter : premiumAt(row,col); }
Game::Game(std::vector<std::string> names, const std::string& dictionaryPath, unsigned seed) : rng_(seed) {
    std::ifstream file(dictionaryPath);
    if (!file) { dictionaryError_ = "Cannot open dictionary: " + dictionaryPath; return; }
    std::string line;
    while (std::getline(file, line)) { line = upper(line); line.erase(std::remove_if(line.begin(), line.end(), [](unsigned char c){ return std::isspace(c) || c == '\r'; }), line.end()); if (!line.empty() && std::all_of(line.begin(), line.end(), [](char c){ return c >= 'A' && c <= 'Z'; })) dictionary_.insert(line); }
    dictionaryLoaded_ = !dictionary_.empty();
    if (!dictionaryLoaded_) { dictionaryError_ = "Dictionary file is empty or contains no usable words."; return; }
    if (names.size() < 2 || names.size() > 4) { dictionaryLoaded_ = false; dictionaryError_ = "Scrabble needs 2 to 4 players."; return; }
    for (auto& name : names) { if (name.empty()) name = "Player" + std::to_string(players_.size()+1); players_.push_back({name,0,{}}); }
    fillBag(); shuffleBag(); for (auto& p : players_) drawTiles(p);
}
void Game::fillBag() {
    const std::array<int,26> counts = {9,2,2,4,12,2,3,2,9,1,1,4,2,6,8,2,1,6,4,6,4,2,2,1,2,1};
    for (int i=0;i<26;++i) for (int n=0;n<counts[i];++n) bag_.push_back(static_cast<char>('A'+i));
}
void Game::shuffleBag() { std::shuffle(bag_.begin(), bag_.end(), rng_); }
void Game::drawTiles(Player& p) { while (p.rack.size() < RACK_SIZE && !bag_.empty()) { p.rack.push_back(bag_.back()); bag_.pop_back(); } }
bool Game::hasWord(const std::string& word) const { return dictionary_.find(word) != dictionary_.end(); }
bool Game::rackCanMake(const Player& p, const std::vector<char>& letters, std::vector<char>& remaining) const {
    remaining = p.rack;
    for (char letter : letters) { auto it = std::find(remaining.begin(), remaining.end(), letter); if (it == remaining.end()) return false; remaining.erase(it); }
    return true;
}
MoveResult Game::play(int row, int col, char direction, const std::string& rawWord) {
    MoveResult result;
    if (gameOver_) { result.message = "The game has ended."; return result; }
    if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) { result.message = "Row and column must be between 1 and 15."; return result; }
    direction = static_cast<char>(std::toupper(static_cast<unsigned char>(direction)));
    if (direction != 'H' && direction != 'V') { result.message = "Direction must be H (horizontal) or V (vertical)."; return result; }
    const std::string word = upper(rawWord);
    if (word.empty() || !std::all_of(word.begin(), word.end(), [](char c){ return c >= 'A' && c <= 'Z'; })) { result.message = "Enter a word containing letters A-Z only."; return result; }
    const int dr = direction == 'V' ? 1 : 0, dc = direction == 'H' ? 1 : 0;
    if (row + dr * (static_cast<int>(word.size())-1) >= BOARD_SIZE || col + dc * (static_cast<int>(word.size())-1) >= BOARD_SIZE) { result.message = "That word extends beyond the board."; return result; }
    // The command must describe the complete word, not just a prefix or suffix.
    int beforeR=row-dr, beforeC=col-dc, afterR=row+dr*static_cast<int>(word.size()), afterC=col+dc*static_cast<int>(word.size());
    if (beforeR>=0 && beforeR<BOARD_SIZE && beforeC>=0 && beforeC<BOARD_SIZE && board_[index(beforeR,beforeC)].occupied) { result.message = "Start earlier to include the existing letter before this word."; return result; }
    if (afterR>=0 && afterR<BOARD_SIZE && afterC>=0 && afterC<BOARD_SIZE && board_[index(afterR,afterC)].occupied) { result.message = "Extend the word to include the existing letter after it."; return result; }
    std::vector<char> needed; std::vector<Position> newPositions; bool overlaps=false;
    for (std::size_t i=0;i<word.size();++i) { int r=row+dr*static_cast<int>(i), c=col+dc*static_cast<int>(i); const auto& cell=board_[index(r,c)]; if (cell.occupied) { overlaps=true; if (cell.letter != word[i]) { result.message = "The word conflicts with an existing tile."; return result; } } else { needed.push_back(word[i]); newPositions.push_back({r,c}); } }
    if (needed.empty()) { result.message = "The move must place at least one new tile."; return result; }
    std::vector<char> remaining;
    if (!rackCanMake(currentPlayer(), needed, remaining)) { result.message = "Your rack does not contain the required letters."; return result; }
    bool touches=false;
    for (auto p : newPositions) for (auto [ar,ac] : std::array<Position,4>{{{p.row-1,p.col},{p.row+1,p.col},{p.row,p.col-1},{p.row,p.col+1}}}) if (ar>=0 && ar<BOARD_SIZE && ac>=0 && ac<BOARD_SIZE && board_[index(ar,ac)].occupied) touches=true;
    if (std::none_of(board_.begin(), board_.end(), [](const Cell& c){return c.occupied;})) { bool centre=false; for (std::size_t i=0;i<word.size();++i) if (row+dr*static_cast<int>(i)==7 && col+dc*static_cast<int>(i)==7) centre=true; if (!centre) { result.message = "The first word must cover the centre square (H8)."; return result; } }
    else if (!touches && !overlaps) { result.message = "Your move must connect to a tile already on the board."; return result; }

    // Compute the main word and all cross-words before changing the board.
    int total=0, mainLetters=0, mainWordMultiplier=1;
    for (std::size_t i=0;i<word.size();++i) { int r=row+dr*static_cast<int>(i), c=col+dc*static_cast<int>(i); const auto& cell=board_[index(r,c)]; int value=letterPoints(word[i]); if (!cell.occupied) { char prem=premiumAt(r,c); if (prem=='d') value*=2; if (prem=='t') value*=3; if (prem=='D') mainWordMultiplier*=2; if (prem=='T') mainWordMultiplier*=3; } mainLetters+=value; }
    if (!hasWord(word)) { result.message = "Invalid word: " + word; return result; }
    if (word.size()>1 || newPositions.size()==1) { total += mainLetters*mainWordMultiplier; result.words.push_back(word); }
    // Build each perpendicular word by temporarily treating the proposed letters as present.
    auto proposedLetter = [&](int r,int c)->char { for (std::size_t i=0;i<word.size();++i) if (row+dr*static_cast<int>(i)==r && col+dc*static_cast<int>(i)==c) return word[i]; const auto& cell=board_[index(r,c)]; return cell.occupied ? cell.letter : ' '; };
    for (auto p : newPositions) {
        int pdr = direction=='H' ? 1 : 0, pdc = direction=='V' ? 1 : 0;
        int sr=p.row, sc=p.col; while (sr-pdr>=0 && sc-pdc>=0 && sr-pdr<BOARD_SIZE && sc-pdc<BOARD_SIZE && proposedLetter(sr-pdr,sc-pdc)!=' ') { sr-=pdr; sc-=pdc; }
        std::string cross; int r=sr,c=sc, crossSum=0, crossMultiplier=1;
        while (r>=0 && r<BOARD_SIZE && c>=0 && c<BOARD_SIZE) { char ch=proposedLetter(r,c); if (ch==' ') break; cross.push_back(ch); int val=letterPoints(ch); bool newlyPlaced=false; for (auto np:newPositions) if(np.row==r&&np.col==c) newlyPlaced=true; if (newlyPlaced) { char prem=premiumAt(r,c); if(prem=='d') val*=2; if(prem=='t') val*=3; if(prem=='D') crossMultiplier*=2; if(prem=='T') crossMultiplier*=3; } crossSum+=val; r+=pdr; c+=pdc; }
        if (cross.size()>1) { if (!hasWord(cross)) { result.message = "Invalid cross-word: " + cross; return result; } total += crossSum*crossMultiplier; result.words.push_back(cross); }
    }
    if (needed.size()==RACK_SIZE) total += 50;
    // Commit only after every validation succeeds.
    for (std::size_t i=0;i<word.size();++i) { int r=row+dr*static_cast<int>(i), c=col+dc*static_cast<int>(i); if (!board_[index(r,c)].occupied) board_[index(r,c)]={word[i],true}; }
    currentPlayer().rack=std::move(remaining); currentPlayer().score+=total; drawTiles(currentPlayer()); consecutiveScorelessTurns_=0;
    result.ok=true; result.points=total; result.message="Move accepted. "+currentPlayer().name+" scored "+std::to_string(total)+" points.";
    if (bag_.empty() && currentPlayer().rack.empty()) finishGame(true); else nextTurn();
    return result;
}
void Game::nextTurn() { currentPlayer_=(currentPlayer_+1)%static_cast<int>(players_.size()); }
std::string Game::pass() { if (gameOver_) return "The game has ended."; ++consecutiveScorelessTurns_; nextTurn(); if (consecutiveScorelessTurns_>=6) finishGame(false); return gameOver_ ? endMessage_ : "Turn passed."; }
std::string Game::exchange(const std::string& rawLetters) {
    if (gameOver_) return "The game has ended.";
    std::string letters=upper(rawLetters); letters.erase(std::remove_if(letters.begin(),letters.end(),[](unsigned char c){return std::isspace(c);}),letters.end());
    if (letters.empty()) return "Enter one or more rack letters to exchange.";
    if (bag_.size()<letters.size()) return "Not enough tiles remain in the bag to exchange that many tiles.";
    std::vector<char> remaining=currentPlayer().rack;
    for(char ch:letters) { auto it=std::find(remaining.begin(),remaining.end(),ch); if(it==remaining.end()) return "Your rack does not contain the requested letters."; remaining.erase(it); }
    for(char ch:letters) bag_.push_back(ch);
    shuffleBag(); currentPlayer().rack=std::move(remaining); drawTiles(currentPlayer()); ++consecutiveScorelessTurns_; nextTurn(); if(consecutiveScorelessTurns_>=6) finishGame(false);
    return gameOver_ ? endMessage_ : "Tiles exchanged.";
}
void Game::finishGame(bool rackOut) {
    if (gameOver_) return;
    gameOver_=true;
    if (rackOut) {
        int winner=currentPlayer_; int leftover=0;
        for(std::size_t i=0;i<players_.size();++i) if(static_cast<int>(i)!=winner) { int points=0; for(char c:players_[i].rack) points+=letterPoints(c); players_[i].score-=points; leftover+=points; }
        players_[winner].score+=leftover;
        endMessage_="Game over: "+players_[winner].name+" emptied their rack and receives the remaining rack points.";
    } else {
        for(auto& p:players_) for(char c:p.rack) p.score-=letterPoints(c);
        endMessage_="Game over after six consecutive scoreless turns. Remaining rack points were deducted.";
    }
    int best=players_.front().score; for(const auto& p:players_) best=std::max(best,p.score);
    std::vector<std::string> winners; for(const auto& p:players_) if(p.score==best) winners.push_back(p.name);
    endMessage_ += " Winner" + std::string(winners.size()>1?"s: ":": "); for(std::size_t i=0;i<winners.size();++i) { if(i) endMessage_ += ", "; endMessage_ += winners[i]; } endMessage_ += " ("+std::to_string(best)+" points).";
    for(const auto& p:players_) saveHighScore(p);
}
void saveHighScore(const Player& p, const std::string& path) { std::ofstream out(path,std::ios::app); if(out) out<<p.score<<';'<<p.name<<'\n'; }
}
